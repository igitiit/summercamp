# 2D: Shooting Projectiles

![alt](http://kidscancode.org/godot_recipes/4.x/img/2d_shoot_03.gif)

Tutorial:
http://kidscancode.org/godot_recipes/4.x/2d_shooting
