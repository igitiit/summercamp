const cells = document.querySelectorAll('.cell');
const scoreDisplay = document.getElementById('score');
const messageDisplay = document.getElementById('message');

let dronePosition = Math.floor(Math.random() * 9);
let score = 0;

// Add a function to update the cell content
function updateCellContent(index, content) {
  cells[index].textContent = content;
}

// Add a function to reset the cell content
function resetCellContent() {
  cells.forEach(cell => cell.textContent = '');
}

// Add a function to update the drone position
function updateDronePosition() {
  resetCellContent();
  dronePosition = Math.floor(Math.random() * 9);
  updateCellContent(dronePosition, '🚁');
}

// Initialize the game
updateDronePosition();

cells.forEach((cell, index) => {
  cell.addEventListener('click', () => {
    if (index === dronePosition) {
      score++;
      scoreDisplay.textContent = score;
      messageDisplay.textContent = 'Valid move! Drone position updated.';
      updateDronePosition();
    } else {
      messageDisplay.textContent = 'Drone destroyed! Game over.';
      resetGame();
    }
  });
});

function resetGame() {
  score = 0;
  scoreDisplay.textContent = score;
  resetCellContent();
  updateDronePosition();
  messageDisplay.textContent = '';
}