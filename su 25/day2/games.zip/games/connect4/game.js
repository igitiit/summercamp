// game.js

// Step 1: Select the board element
const boardElement = document.getElementById('board');

// Step 2: Create the cells and add them to the board
const cells = [];
for (let i = 0; i < 42; i++) {
    const cell = document.createElement('div');
    cell.classList.add('cell');
    boardElement.appendChild(cell);
    cells.push(cell);
}

// Step 3: Initialize game variables
let currentPlayer = 'red'; // 'red' or 'yellow'
const winningCombinations = [
    // Horizontal combinations
    [0, 1, 2, 3], [1, 2, 3, 4], [2, 3, 4, 5], [3, 4, 5, 6],
    [7, 8, 9, 10], [8, 9, 10, 11], [9, 10, 11, 12], [10, 11, 12, 13],
    [14, 15, 16, 17], [15, 16, 17, 18], [16, 17, 18, 19], [17, 18, 19, 20],
    [21, 22, 23, 24], [22, 23, 24, 25], [23, 24, 25, 26], [24, 25, 26, 27],
    [28, 29, 30, 31], [29, 30, 31, 32], [30, 31, 32, 33], [31, 32, 33, 34],
    [35, 36, 37, 38], [36, 37, 38, 39], [37, 38, 39, 40], [38, 39, 40, 41],
    // Vertical combinations
    [0, 7, 14, 21], [1, 8, 15, 22], [2, 9, 16, 23], [3, 10, 17, 24],
    [4, 11, 18, 25], [5, 12, 19, 26], [6, 13, 20, 27],
    [7, 14, 21, 28], [8, 15, 22, 29], [9, 16, 23, 30], [10, 17, 24, 31],
    [11, 18, 25, 32], [12, 19, 26, 33], [13, 20, 27, 34],
    [14, 21, 28, 35], [15, 22, 29, 36], [16, 23, 30, 37], [17, 24, 31, 38],
    [18, 25, 32, 39], [19, 26, 33, 40], [20, 27, 34, 41],
    // Diagonal combinations
    [0, 8, 16, 24], [1, 9, 17, 25], [2, 10, 18, 26], [3, 11, 19, 27],
    [7, 15, 23, 31], [8, 16, 24, 32], [9, 17, 25, 33], [10, 18, 26, 34],
    [14, 22, 30, 38], [15, 23, 31, 39], [16, 24, 32, 40], [17, 25, 33, 41],
    [21, 29, 37, 38], [22, 30, 38, 39], [23, 31, 39, 40], [24, 32, 40, 41],
    [3, 9, 15, 21], [4, 10, 16, 22], [5, 11, 17, 23], [6, 12, 18, 24],
    [10, 16, 22, 28], [11, 17, 23, 29], [12, 18, 24, 30], [13, 19, 25, 31],
    [17, 23, 29, 35], [18, 24, 30, 36], [19, 25, 31, 37], [20, 26, 32, 38]
];

// Step 4: Add event listeners to cells
cells.forEach((cell, index) => {
    cell.addEventListener('click', () => {
        // Get the column index from the cell index
        const column = index % 7;

        // Find the lowest available row in the column
        let row = 5; // Start from the bottom row
        while (row >= 0 && cells[column + row * 7].classList.contains('red', 'yellow')) {
            row--;
        }

        // If the column is not full
        if (row >= 0) {
            // Place the current player's disc in the lowest available row
            cells[column + row * 7].classList.add(currentPlayer);

            // Check if the current player has won
            if (checkWin(currentPlayer, column + row * 7)) {
                alert(`Player ${currentPlayer} wins!`);
                resetGame();
                return;
            }

            // Check if the game is a tie
            if (checkTie()) {
                alert("It's a tie!");
                resetGame();
                return;
            }

            // Switch to the other player's turn
            currentPlayer = currentPlayer === 'red' ? 'yellow' : 'red';
        }
    });
});

// Step 5: Implement the checkWin function
function checkWin(player, index) {
    return winningCombinations.some(combination => {
        return combination.every(cellIndex => {
            return cells[cellIndex].classList.contains(player);
        });
    });
}

// Step 6: Implement the checkTie function
function checkTie() {
    return cells.every(cell => cell.classList.contains('red') || cell.classList.contains('yellow'));
}

// Step 7: Implement the resetGame function
function resetGame() {
    cells.forEach(cell => {
        cell.classList.remove('red', 'yellow');
    });
    currentPlayer = 'red';
}