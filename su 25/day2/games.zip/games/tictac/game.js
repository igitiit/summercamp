
// game.js

// Step 1: Select the board element
const boardElement = document.getElementById('board');

// Step 2: Create the cells and add them to the board
const cells = [];
for (let i = 0; i < 9; i++) {
    const cell = document.createElement('div');
    cell.classList.add('cell');
    boardElement.appendChild(cell);
    cells.push(cell);
}

// Step 3: Initialize game variables
let currentPlayer = 'X'; // 'X' or 'O'
const winningCombinations = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
    [0, 4, 8], [2, 4, 6] // Diagonals
];

// Step 4: Add event listeners to cells
cells.forEach((cell, index) => {
    cell.addEventListener('click', () => {
        // Hint: Check if the cell is already marked
        if (cell.textContent !== '') return;

        // Hint: Mark the cell with the current player's symbol
        cell.textContent = currentPlayer;

        // Hint: Check if the current player has won
        if (checkWin(currentPlayer, index)) {
            // Hint: Display a message and reset the game
            alert(`Player ${currentPlayer} wins!`);
            resetGame();
            return;
        }

        // Hint: Check if the game is a tie
        if (checkTie()) {
            // Hint: Display a message and reset the game
            alert("It's a tie!");
            resetGame();
            return;
        }

        // Hint: Switch to the other player's turn
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    });
});

// Step 5: Implement the checkWin function
function checkWin(player, index) {
    // Hint: Check if the current player's moves match any of the winning combinations
    for (let i = 0; i < winningCombinations.length; i++) {
        const combination = winningCombinations[i];
        console.log(combination)
        if (combination.includes(index)) {
            const a = combination[0];
            const b = combination[1];
            const c = combination[2];
            if (
                cells[a].textContent === player &&
                cells[b].textContent === player &&
                cells[c].textContent === player
            ) {
                return true;
            }
        }
    }
    return false;
}

// Step 6: Implement the checkTie function
function checkTie() {
    // Hint: Check if all cells are marked and there is no winner
    return cells.every(function(cell) {
        return cell.textContent !== '';
    }) && !winningCombinations.some(function(combination) {
        const [a, b, c] = combination;
        return (
            cells[a].textContent === currentPlayer &&
            cells[b].textContent === currentPlayer &&
            cells[c].textContent === currentPlayer
        );
    });
}

// Step 7: Implement the resetGame function
function resetGame() {
    // Hint: Clear the content of all cells
    cells.forEach(cell => cell.textContent = '');

    // Hint: Reset the current player
    currentPlayer = 'X';
}