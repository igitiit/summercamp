// Get the canvas element
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Game constants
const TILE_SIZE = 40;
const PLAYER_SIZE = 25;
const MAZE_WIDTH = 12;
const MAZE_HEIGHT = 12;
const PLAYER_SPEED = 2;

// Timer variables
let timeLeft = 30;
let timerInterval;
const timerElement = document.getElementById('timer');

// Game state
let gameOver = false;

// Function to update the timer
function updateTimer() {
    timerElement.textContent = timeLeft;
    if (timeLeft === 0) {
        clearInterval(timerInterval);
        endGame();
    } else {
        timeLeft--;
    }
}

// Start the timer
timerInterval = setInterval(updateTimer, 1000);

// Simple maze layout (0 = wall, 1 = path, 2 = exit)
let maze = [
    [1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0],
    [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0],
    [0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0],
    [0, 1, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0],
    [0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1, 0],
    [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0],
    [0, 1, 1, 1, 1, 0, 0, 0, 1, 0, 1, 1],
    [0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2] // Exit point at the bottom right corner
];

// Find the first open tile to place the player
let playerX, playerY;
for (let y = 0; y < MAZE_HEIGHT; y++) {
    for (let x = 0; x < MAZE_WIDTH; x++) {
        if (maze[y][x] === 1) {
            playerX = x * TILE_SIZE + TILE_SIZE / 2;
            playerY = y * TILE_SIZE + TILE_SIZE / 2;
            break;
        }
    }
    if (playerX && playerY) break;
}

// Player movement
let moveUp = false;
let moveDown = false;
let moveLeft = false;
let moveRight = false;

// Draw the maze
function drawMaze() {
    for (let y = 0; y < MAZE_HEIGHT; y++) {
        for (let x = 0; x < MAZE_WIDTH; x++) {
            if (maze[y][x] === 0) {
                ctx.fillStyle = '#00A000';
                ctx.fillRect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
            } else if (maze[y][x] === 2) {
                ctx.fillStyle = '#FFD700'; // Color for the exit point
                ctx.fillRect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
            }
        }
    }
}

// Draw the player
function drawPlayer() {
    ctx.fillStyle = '#FF0000';
    ctx.fillRect(playerX - PLAYER_SIZE / 2, playerY - PLAYER_SIZE / 2, PLAYER_SIZE, PLAYER_SIZE);
}

// Check if a position is valid (not colliding with walls)
function isValidPosition(x, y) {
    const leftEdge = x - PLAYER_SIZE / 2;
    const rightEdge = x + PLAYER_SIZE / 2 - 1;
    const topEdge = y - PLAYER_SIZE / 2;
    const bottomEdge = y + PLAYER_SIZE / 2 - 1;

    const leftTile = Math.floor(leftEdge / TILE_SIZE);
    const rightTile = Math.floor(rightEdge / TILE_SIZE);
    const topTile = Math.floor(topEdge / TILE_SIZE);
    const bottomTile = Math.floor(bottomEdge / TILE_SIZE);

    return (
        maze[topTile] && maze[bottomTile] &&
        (maze[topTile][leftTile] === 1 || maze[topTile][leftTile] === 2) &&
        (maze[topTile][rightTile] === 1 || maze[topTile][rightTile] === 2) &&
        (maze[bottomTile][leftTile] === 1 || maze[bottomTile][leftTile] === 2) &&
        (maze[bottomTile][rightTile] === 1 || maze[bottomTile][rightTile] === 2)
    );
}

// Check if player reached the exit
function checkForExit() {
    const playerTileX = Math.floor(playerX / TILE_SIZE);
    const playerTileY = Math.floor(playerY / TILE_SIZE);

    if (maze[playerTileY][playerTileX] === 2 && timeLeft > 0) {
        // Player reached the exit and time is not up
        endGame(true);
    }
}

// Update player position
function updatePlayerPosition() {
    if (gameOver) return;

    let newX = playerX;
    let newY = playerY;

    if (moveUp) newY -= PLAYER_SPEED;
    if (moveDown) newY += PLAYER_SPEED;
    if (moveLeft) newX -= PLAYER_SPEED;
    if (moveRight) newX += PLAYER_SPEED;

    // Check for collisions
    if (isValidPosition(newX, newY)) {
        playerX = newX;
        playerY = newY;
    } else {
        // If invalid, try moving only horizontally or vertically
        if (isValidPosition(newX, playerY)) {
            playerX = newX;
        } else if (isValidPosition(playerX, newY)) {
            playerY = newY;
        }
    }

    // Check if player reached the exit
    checkForExit();
}

// End the game
function endGame(win = false) {
    if (gameOver) return;
    
    gameOver = true;
    clearInterval(timerInterval);

    // Display game over message
    ctx.fillStyle = 'white';
    ctx.font = '30px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(win ? 'You Win!' : 'Game Over!', canvas.width / 2, canvas.height / 2);

    // Prompt for name and save score
    promptAndSaveScore();
}

// Function to save the score
function saveScore(name, score) {
    let scores = JSON.parse(localStorage.getItem('scores')) || [];
    scores.push({ name, score });
    localStorage.setItem('scores', JSON.stringify(scores));
}

// Function to prompt for name and save score
function promptAndSaveScore() {
    const name = prompt("Enter your name:");
    if (name) {
        saveScore(name, timeLeft);
        window.location.href = 'index2.html';
    }
}

// Main game loop
function gameLoop() {
    // Clear the canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Update player position
    updatePlayerPosition();

    // Draw the maze and player
    drawMaze();
    drawPlayer();

    // Request the next frame if the game is not over
    if (!gameOver) {
        requestAnimationFrame(gameLoop);
    }
}

// Handle keyboard input
document.addEventListener('keydown', (event) => {
    if (gameOver) return;
    const key = event.key;
    if (key === 'ArrowUp') moveUp = true;
    if (key === 'ArrowDown') moveDown = true;
    if (key === 'ArrowLeft') moveLeft = true;
    if (key === 'ArrowRight') moveRight = true;
});

document.addEventListener('keyup', (event) => {
    const key = event.key;
    if (key === 'ArrowUp') moveUp = false;
    if (key === 'ArrowDown') moveDown = false;
    if (key === 'ArrowLeft') moveLeft = false;
    if (key === 'ArrowRight') moveRight = false;
});

// Start the game
gameLoop();