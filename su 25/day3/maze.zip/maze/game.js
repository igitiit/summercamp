// Get the canvas element
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Game constants
const TILE_SIZE = 40;
const PLAYER_SIZE = 25;
const MAZE_WIDTH = 12;
const MAZE_HEIGHT = 12;
const PLAYER_SPEED = 2;

// Simple maze layout (0 = wall, 1 = path)
let maze = [
    [1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0],
    [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0],
    [0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0],
    [0, 1, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0],
    [0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1, 0],
    [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0],
    [0, 1, 1, 1, 1, 0, 0, 0, 1, 0, 1, 1],
    [0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1]
];

// Find the first open tile to place the player
let playerX, playerY;
for (let y = 0; y < MAZE_HEIGHT; y++) {
    for (let x = 0; x < MAZE_WIDTH; x++) {
        if (maze[y][x] === 1) {
            playerX = x * TILE_SIZE + TILE_SIZE / 2;
            playerY = y * TILE_SIZE + TILE_SIZE / 2;
            break;
        }
    }
    if (playerX && playerY) break;
}

// Player movement
let moveUp = false;
let moveDown = false;
let moveLeft = false;
let moveRight = false;

// Draw the maze
function drawMaze() {
    for (let y = 0; y < MAZE_HEIGHT; y++) {
        for (let x = 0; x < MAZE_WIDTH; x++) {
            if (maze[y][x] === 0) {
                ctx.fillStyle = '#00A000';
                ctx.fillRect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
            }
        }
    }
}

// Draw the player
function drawPlayer() {
    ctx.fillStyle = '#FF0000';
    ctx.fillRect(playerX - PLAYER_SIZE / 2, playerY - PLAYER_SIZE / 2, PLAYER_SIZE, PLAYER_SIZE);
}

// Check if a position is valid (not colliding with walls)
function isValidPosition(x, y) {
    const leftEdge = x - PLAYER_SIZE / 2;
    const rightEdge = x + PLAYER_SIZE / 2 - 1;
    const topEdge = y - PLAYER_SIZE / 2;
    const bottomEdge = y + PLAYER_SIZE / 2 - 1;

    const leftTile = Math.floor(leftEdge / TILE_SIZE);
    const rightTile = Math.floor(rightEdge / TILE_SIZE);
    const topTile = Math.floor(topEdge / TILE_SIZE);
    const bottomTile = Math.floor(bottomEdge / TILE_SIZE);

    return (
        maze[topTile] && maze[bottomTile] &&
        maze[topTile][leftTile] === 1 &&
        maze[topTile][rightTile] === 1 &&
        maze[bottomTile][leftTile] === 1 &&
        maze[bottomTile][rightTile] === 1
    );
}

// Update player position
function updatePlayerPosition() {
    let newX = playerX;
    let newY = playerY;

    if (moveUp) newY -= PLAYER_SPEED;
    if (moveDown) newY += PLAYER_SPEED;
    if (moveLeft) newX -= PLAYER_SPEED;
    if (moveRight) newX += PLAYER_SPEED;

    // Check for collisions
    if (isValidPosition(newX, newY)) {
        playerX = newX;
        playerY = newY;
    } else {
        // If invalid, try moving only horizontally or vertically
        if (isValidPosition(newX, playerY)) {
            playerX = newX;
        } else if (isValidPosition(playerX, newY)) {
            playerY = newY;
        }
    }
}

// Main game loop
function gameLoop() {
    // Clear the canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Update player position
    updatePlayerPosition();

    // Draw the maze and player
    drawMaze();
    drawPlayer();

    // Request the next frame
    requestAnimationFrame(gameLoop);
}

// Handle keyboard input
document.addEventListener('keydown', (event) => {
    const key = event.key;
    if (key === 'ArrowUp') moveUp = true;
    if (key === 'ArrowDown') moveDown = true;
    if (key === 'ArrowLeft') moveLeft = true;
    if (key === 'ArrowRight') moveRight = true;
});

document.addEventListener('keyup', (event) => {
    const key = event.key;
    if (key === 'ArrowUp') moveUp = false;
    if (key === 'ArrowDown') moveDown = false;
    if (key === 'ArrowLeft') moveLeft = false;
    if (key === 'ArrowRight') moveRight = false;
});

// Start the game
gameLoop();
